import ContactContent from "../components/ContactContent";

function ContactUsPage()
{
    return(
        <>
            <ContactContent />
        </>
    )
}
export default ContactUsPage;