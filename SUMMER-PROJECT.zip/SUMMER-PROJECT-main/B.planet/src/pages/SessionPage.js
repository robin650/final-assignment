import Session from "../components/SessionExpired";

function SessionPage()
{
    return(
        <>
            <Session />
        </>
    );
}

export default SessionPage;