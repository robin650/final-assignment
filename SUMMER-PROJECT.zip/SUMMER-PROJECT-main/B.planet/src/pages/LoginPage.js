import LoginContent from "../components/LoginContent";

function LoginPage()
{
    return(
        <>
            <LoginContent />
        </>
    )
}
export default LoginPage;