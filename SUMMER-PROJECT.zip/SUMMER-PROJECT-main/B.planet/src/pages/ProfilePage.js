import ProfileContent from "../components/ProfileContent";

function ProfilePage()
{
    return(
        <>
            <ProfileContent />
        </>
    );
}

export default ProfilePage;