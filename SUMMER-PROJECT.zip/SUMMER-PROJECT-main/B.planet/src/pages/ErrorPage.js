import Error from "../components/ErrorComponent";

function ErrorPage()
{
    return(
        <>
            <Error />
        </>
    )
}
export default ErrorPage;