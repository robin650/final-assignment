import React from "react";
import SigninContent from "../components/SigninContent";

function Signup()
{
    return(
        <>
            <SigninContent />
        </>
    )
}
export default Signup;